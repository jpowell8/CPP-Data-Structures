#include "Pair.h"


Pair::Pair(string key, string suffix)
{
	Key=key;
	Suffix.push_back(suffix);

}


Pair::~Pair(void)
{
}
